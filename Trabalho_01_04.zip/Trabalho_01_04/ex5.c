#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define N 1000000

int A[N], B[N], C[N];
int num_threads;

typedef struct {
    int inicio;
    int fim;
} Intervalo;

void* soma(void* arg) {
    Intervalo* intervalo = (Intervalo*) arg;

    for (int i = intervalo->inicio; i < intervalo->fim; i++) {
        C[i] = A[i] + B[i];
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t* threads;
    Intervalo* intervalos;

    struct timeval inicio, fim;

    printf("Digite o numero de threads: ");
    scanf("%d", &num_threads);

    threads = malloc(num_threads * sizeof(pthread_t));
    intervalos = malloc(num_threads * sizeof(Intervalo));

    // Inicio vetor
    for (int i = 0; i < N; i++) {
        A[i] = i;
        B[i] = i * 2;
    }

    int bloco = N / num_threads;

//inicio
    gettimeofday(&inicio, NULL);

    
    for (int i = 0; i < num_threads; i++) {
        intervalos[i].inicio = i * bloco;
        intervalos[i].fim = (i == num_threads - 1) ? N : (i + 1) * bloco;

        pthread_create(&threads[i], NULL, soma, &intervalos[i]);
    }

    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
//fim
    gettimeofday(&fim, NULL);

    double tempo = (fim.tv_sec - inicio.tv_sec) +
                   (fim.tv_usec - inicio.tv_usec) / 1000000.0;

    printf("Tempo de execucao: %f segundos\n", tempo);

    // Mostra alguns resultados
    printf("C[0] = %d\n", C[0]);
    printf("C[N-1] = %d\n", C[N-1]);

    free(threads);
    free(intervalos);

    return 0;
}





//a) O tempo de execução foi medido utilizando a função gettimeofday, que permite obter o tempo com precisão
//b) Para este problema, a implementação de threads é mais eficiente, pois compartilham o mesmo espaço de memória, menor custo de criação e nãpo necessitam de mecanismo para comunicação entre processos
//c) Houve várias threads trabalhando ao mesmo tempo, mas sem dar problema, porque cada uma mexe em uma parte diferente do vetor.