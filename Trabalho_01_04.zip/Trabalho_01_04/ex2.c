#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

int N;

void* thread1(void* arg){
    for(int i=1; i<=N; i++){
        
        printf("Thread 1 ==>interacao %d\n", i);
        usleep(100000);
    }
    return NULL;
}

void* thread2(void* arg){
    for(int i= 1; i<=N; i++){
        printf("Thread 2 ==> interacao %d\n", i);
        usleep(100000);
    }
    return NULL;
}

void* thread3(void* arg){
    for(int i= 1; i<=N; i++){
        printf("Thread 3 ==> interacao %d\n", i);
        usleep(100000);
    }
    return NULL;
}


int main() {
    
    pthread_t t1, t2, t3;
    
    printf("Digite o numero de interacoes N (para as 3 threads):\n");
    scanf("%d", &N);
    
    pthread_create(&t1, NULL, thread1, NULL);
    pthread_create(&t2, NULL, thread2, NULL);
    pthread_create(&t3, NULL, thread3, NULL);
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    
    return 0;
}

//O escalonamento é  controlado pelo sistema operacional. 