#include <stdio.h>
#include <pthread.h>

float largura, comprimento;
float area, perimetro;

void* calcularArea(void* arg) {
    area = largura * comprimento;
    return NULL;
}

void* calcularPerimetro(void* arg) {
    perimetro = 2 * (largura + comprimento);
    return NULL;
}

int main() {
    pthread_t t1, t2;

    printf("Digite a largura do terreno: ");
    scanf("%f", &largura);

    printf("Digite o comprimento do terreno: ");
    scanf("%f", &comprimento);

    pthread_create(&t1, NULL, calcularArea, NULL);
    pthread_create(&t2, NULL, calcularPerimetro, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("\*** RESULTADOS **\n");
    printf("Area: %.2f\n", area);
    printf("Perimetro: %.2f\n", perimetro);

    return 0;
}