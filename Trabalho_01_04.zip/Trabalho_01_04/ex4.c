#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

int vetor[5];
int count = 0;

void* produtor(void* arg) {
    int valor = 1;

    while (1) {
        if (count < 5) {
            vetor[count] = valor;
            printf("Inseriu: %d\n", valor);
            count++;
            valor++;
        }
        usleep(100000); 
    }
}

void* consumidor(void* arg) {
    while (1) {
        if (count > 0) {
            int valor = vetor[count - 1];
            printf("Removeu: %d\n", valor);
            count--;
        }
        usleep(150000);
    }
}

int main() {
    pthread_t t1, t2;

    pthread_create(&t1, NULL, produtor, NULL);
    pthread_create(&t2, NULL, consumidor, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    return 0;
}







// 4a)Programa roda normalmente, mas há problemas na concorrência.Quando é inserido e removido o "count" pode ficar errado e dados podem ser substituidos
//4b) Os dados não são confiáveis sem sincronização
//4c) É necessário sincronizar