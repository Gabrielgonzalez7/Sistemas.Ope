#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

int contador = 0;
int N, T;

void* incrementar(void* arg) {
    for (int i = 0; i < N; i++) {
        contador++; // sem proteção
    }
    return NULL;
}

int main() {
    printf("Digite a quantidade de threads: ");
    scanf("%d", &T);

    printf("Digite o numero de iteracoes por thread: ");
    scanf("%d", &N);

    pthread_t threads[T];

    for (int i = 0; i < T; i++) {
        pthread_create(&threads[i], NULL, incrementar, NULL);
    }

    for (int i = 0; i < T; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("\nValor esperado: %d\n", T * N);
    printf("Valor final do contador: %d\n", contador);

    return 0;
}