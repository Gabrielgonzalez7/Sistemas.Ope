package pkg;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author laboratorio
 */
public class Mensagem {
    private boolean pronta = false;
    
    public synchronized void esperarMensagem(){
        while(!pronta){
            try {
                System.out.println("Thread esperando mensagem");
                wait();
            } catch(InterruptedException e){
                e.printStackTrace();
                
            }
        }
        System.err.println("Mensagem recebida");
    }
    public synchronized void enviarMensagem(){
        System.out.println("preparando mensagem...");
        pronta = true;
        notify();
        System.out.println("Mensagem enviada");
        
    }
    
}
